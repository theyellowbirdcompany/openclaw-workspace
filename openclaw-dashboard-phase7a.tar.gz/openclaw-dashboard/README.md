# OpenClaw Dashboard — Phase 7a Command Center

Real-time Command Center for the Agent OS v3. Built with Vite + React + Tailwind CSS + Supabase.

## Features

- **North Star Banner** — Displays the active North Star from `north_star` table
- **Agent Grid** — All 7 agents with live status, pulse rings, and current task (from `agent_status` table)
  - 🟢 Active = emerald `animate-ping` pulse ring
  - ⚫ Idle/Offline = grey dot
- **Activity Feed** — Latest 10 entries from `agent_logs` with realtime updates
- **Dark Slate Sidebar** — Navigation for all 5 pages
- **Stub Routes** — Pages 2–5 (Agents, Logs, Costs, Settings) render "Coming Soon"
- **Realtime** — Agent grid and activity feed use Supabase Realtime subscriptions

## Pages

| Route | Status |
|-------|--------|
| `/` | ✅ Command Center (Phase 7a) |
| `/agents` | 🚧 Coming Soon (Phase 7b+) |
| `/logs` | 🚧 Coming Soon |
| `/costs` | 🚧 Coming Soon |
| `/settings` | 🚧 Coming Soon |

## Setup

### 1. Clone the repo

```bash
git clone https://github.com/FrozenCorn2113/OpenClaw_Dashboard.git
cd OpenClaw_Dashboard
npm install
```

### 2. Configure environment variables

```bash
cp .env.example .env
```

Edit `.env` and fill in your Supabase credentials:

```
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
```

> ⚠️ **Never commit `.env` to the repo.** It's in `.gitignore`. For Vercel deployments, add env vars through the Vercel dashboard.

### 3. Run locally

```bash
npm run dev
```

### 4. Build for production

```bash
npm run build
```

## Environment Variables

| Variable | Description |
|----------|-------------|
| `VITE_SUPABASE_URL` | Your Supabase project URL |
| `VITE_SUPABASE_ANON_KEY` | Your Supabase anon (public) key |

## Supabase Schema

Tables used by this dashboard:

### `north_star`
- `id` (uuid, PK)
- `title` (text)
- `prompt` (text)
- `is_active` (boolean)
- `set_by` (text)
- `created_at` (timestamptz)

### `agent_status`
- `agent_name` (text, PK)
- `status` (text) — `active` | `idle`
- `current_task` (text)
- `last_seen` (timestamptz)
- `updated_at` (timestamptz)

### `agent_logs`
- `id` (uuid, PK)
- `agent_name` (text)
- `task_description` (text)
- `status` (text)
- `tokens_used` (integer)
- `cost_usd` (numeric)
- `created_at` (timestamptz)
- `archived_at` (timestamptz) — NULL = active

## Tech Stack

- [Vite](https://vitejs.dev/) — Build tool
- [React](https://react.dev/) — UI
- [Tailwind CSS](https://tailwindcss.com/) — Styling
- [Supabase JS](https://supabase.com/docs/reference/javascript) — Data + Realtime
- [React Router](https://reactrouter.com/) — Routing

## Deployment

Deploy to Vercel:

1. Connect the GitHub repo in Vercel
2. Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in Vercel project settings → Environment Variables
3. Deploy — Vite builds are auto-detected

---

*Agent OS v3 · Phase 7a · Built by Devan*

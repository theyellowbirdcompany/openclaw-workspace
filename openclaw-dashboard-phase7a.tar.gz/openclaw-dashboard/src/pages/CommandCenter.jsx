import NorthStarBanner from '../components/NorthStarBanner'
import AgentGrid from '../components/AgentGrid'
import ActivityFeed from '../components/ActivityFeed'

export default function CommandCenter() {
  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-white">Command Center</h1>
        <p className="text-slate-400 text-sm mt-1">Real-time view of the Agent OS</p>
      </div>

      <NorthStarBanner />
      <AgentGrid />
      <ActivityFeed />
    </div>
  )
}

export default function ComingSoon({ title }) {
  return (
    <div className="p-8 max-w-7xl mx-auto flex flex-col items-center justify-center min-h-[60vh]">
      <div className="text-5xl mb-4">🚧</div>
      <h1 className="text-2xl font-bold text-white mb-2">{title}</h1>
      <p className="text-slate-400 text-sm">Coming soon — Phase 7b+</p>
    </div>
  )
}

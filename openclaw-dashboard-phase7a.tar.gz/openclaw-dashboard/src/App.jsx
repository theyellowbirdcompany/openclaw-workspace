import { BrowserRouter, Routes, Route } from 'react-router-dom'
import Sidebar from './components/Sidebar'
import CommandCenter from './pages/CommandCenter'
import ComingSoon from './pages/ComingSoon'

export default function App() {
  return (
    <BrowserRouter>
      <div className="flex min-h-screen bg-slate-900">
        <Sidebar />
        <main className="flex-1 overflow-auto">
          <Routes>
            <Route path="/"         element={<CommandCenter />} />
            <Route path="/agents"   element={<ComingSoon title="Agents" />} />
            <Route path="/logs"     element={<ComingSoon title="Logs" />} />
            <Route path="/costs"    element={<ComingSoon title="Costs" />} />
            <Route path="/settings" element={<ComingSoon title="Settings" />} />
          </Routes>
        </main>
      </div>
    </BrowserRouter>
  )
}

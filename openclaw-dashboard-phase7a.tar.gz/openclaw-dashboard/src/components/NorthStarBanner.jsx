import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

export default function NorthStarBanner() {
  const [northStar, setNorthStar] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchNorthStar() {
      const { data, error } = await supabase
        .from('north_star')
        .select('id, title, prompt, set_by, created_at')
        .eq('is_active', true)
        .order('created_at', { ascending: false })
        .limit(1)
        .single()

      if (!error && data) {
        setNorthStar(data)
      }
      setLoading(false)
    }

    fetchNorthStar()
  }, [])

  if (loading) {
    return (
      <div className="w-full bg-slate-800 border border-slate-700 rounded-xl px-6 py-4 mb-6 animate-pulse">
        <div className="h-4 bg-slate-700 rounded w-1/3 mb-2" />
        <div className="h-3 bg-slate-700 rounded w-2/3" />
      </div>
    )
  }

  if (!northStar) {
    return (
      <div className="w-full bg-slate-800 border border-slate-700 rounded-xl px-6 py-4 mb-6">
        <p className="text-slate-500 text-sm">⭐ No active North Star set.</p>
      </div>
    )
  }

  return (
    <div className="w-full bg-gradient-to-r from-indigo-900/50 to-slate-800 border border-indigo-700/50 rounded-xl px-6 py-4 mb-6">
      <div className="flex items-center gap-2 mb-1">
        <span className="text-yellow-400 text-lg">⭐</span>
        <span className="text-xs uppercase tracking-widest text-indigo-400 font-semibold">North Star</span>
        <span className="text-xs text-slate-500 ml-auto">Set by {northStar.set_by}</span>
      </div>
      <h2 className="text-lg font-bold text-white mb-1">{northStar.title}</h2>
      <p className="text-slate-300 text-sm leading-relaxed">{northStar.prompt}</p>
    </div>
  )
}

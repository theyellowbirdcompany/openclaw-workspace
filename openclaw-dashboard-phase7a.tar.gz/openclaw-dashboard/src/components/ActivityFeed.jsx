import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

const STATUS_STYLES = {
  completed: 'text-emerald-400 bg-emerald-900/30',
  failed:    'text-red-400    bg-red-900/30',
  running:   'text-yellow-400 bg-yellow-900/30',
  pending:   'text-slate-400  bg-slate-700/50',
}

function statusStyle(status) {
  return STATUS_STYLES[status?.toLowerCase()] || STATUS_STYLES.pending
}

function timeAgo(ts) {
  if (!ts) return ''
  const diff = Math.floor((Date.now() - new Date(ts).getTime()) / 1000)
  if (diff < 60) return `${diff}s ago`
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`
  return `${Math.floor(diff / 86400)}d ago`
}

export default function ActivityFeed() {
  // Columns: id, agent_name, task_description, model_used, tokens_used, cost_usd,
  //          status, north_star_id, created_at, run_id, archived_at
  const [logs, setLogs] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchLogs() {
      const { data, error } = await supabase
        .from('agent_logs')
        .select('id, agent_name, task_description, status, created_at, tokens_used, cost_usd')
        .is('archived_at', null)
        .order('created_at', { ascending: false })
        .limit(10)

      if (!error && data) setLogs(data)
      setLoading(false)
    }

    fetchLogs()

    // Realtime subscription
    const channel = supabase
      .channel('agent_logs_feed')
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'agent_logs' }, payload => {
        setLogs(prev => [payload.new, ...prev].slice(0, 10))
      })
      .subscribe()

    return () => supabase.removeChannel(channel)
  }, [])

  return (
    <section>
      <h2 className="text-sm uppercase tracking-widest text-slate-400 font-semibold mb-4">Activity Feed</h2>
      <div className="bg-slate-800 border border-slate-700 rounded-xl overflow-hidden">
        {loading ? (
          <div className="p-6 space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <div key={i} className="h-4 bg-slate-700 rounded animate-pulse" />
            ))}
          </div>
        ) : logs.length === 0 ? (
          <div className="p-6 text-slate-500 text-sm">No activity yet.</div>
        ) : (
          <ul className="divide-y divide-slate-700">
            {logs.map(log => (
              <li key={log.id} className="px-5 py-3 flex items-start gap-4 hover:bg-slate-700/30 transition-colors">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-0.5">
                    <span className="font-semibold text-white text-sm">{log.agent_name}</span>
                    <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${statusStyle(log.status)}`}>
                      {log.status || 'unknown'}
                    </span>
                  </div>
                  <p className="text-xs text-slate-300 truncate" title={log.task_description || ''}>
                    {log.task_description || <span className="text-slate-600">No description</span>}
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <div className="text-xs text-slate-500">{timeAgo(log.created_at)}</div>
                  {log.cost_usd != null && (
                    <div className="text-xs text-slate-600">${Number(log.cost_usd).toFixed(4)}</div>
                  )}
                </div>
              </li>
            ))}
          </ul>
        )}
      </div>
    </section>
  )
}

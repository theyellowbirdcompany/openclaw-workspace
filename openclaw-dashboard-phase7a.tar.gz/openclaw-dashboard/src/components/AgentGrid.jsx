import { useEffect, useState } from 'react'
import { supabase } from '../lib/supabase'

// Static roster — merged with live agent_status data
const AGENT_ROSTER = [
  { name: 'Claw',        role: 'Orchestrator',  emoji: '🎩' },
  { name: 'Bernard',     role: 'Strategist',    emoji: '🧠' },
  { name: 'Christopher', role: 'Researcher',    emoji: '🔍' },
  { name: 'Devan',       role: 'Builder',       emoji: '🔧' },
  { name: 'Vale',        role: 'Growth',        emoji: '📈' },
  { name: 'Scribe',      role: 'Communicator',  emoji: '✍️' },
  { name: 'Atlas',       role: 'Ops',           emoji: '⚙️' },
]

function PulseRing({ status }) {
  const isActive = status === 'active'
  return (
    <span className="relative flex h-3 w-3">
      {isActive ? (
        <>
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
          <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500" />
        </>
      ) : (
        <span className="relative inline-flex rounded-full h-3 w-3 bg-slate-500" />
      )}
    </span>
  )
}

function timeAgo(ts) {
  if (!ts) return 'never'
  const diff = Math.floor((Date.now() - new Date(ts).getTime()) / 1000)
  if (diff < 60) return `${diff}s ago`
  if (diff < 3600) return `${Math.floor(diff / 60)}m ago`
  if (diff < 86400) return `${Math.floor(diff / 3600)}h ago`
  return `${Math.floor(diff / 86400)}d ago`
}

export default function AgentGrid() {
  const [liveStatus, setLiveStatus] = useState({})
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function fetchStatus() {
      // Columns: agent_name, last_seen, current_task, status, created_at, updated_at
      const { data, error } = await supabase
        .from('agent_status')
        .select('agent_name, last_seen, current_task, status, updated_at')

      if (!error && data) {
        const map = {}
        data.forEach(row => { map[row.agent_name] = row })
        setLiveStatus(map)
      }
      setLoading(false)
    }

    fetchStatus()

    // Realtime subscription
    const channel = supabase
      .channel('agent_status_changes')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'agent_status' }, payload => {
        setLiveStatus(prev => ({
          ...prev,
          [payload.new.agent_name]: payload.new,
        }))
      })
      .subscribe()

    return () => supabase.removeChannel(channel)
  }, [])

  const agents = AGENT_ROSTER.map(agent => ({
    ...agent,
    ...(liveStatus[agent.name] || {}),
  }))

  return (
    <section className="mb-8">
      <h2 className="text-sm uppercase tracking-widest text-slate-400 font-semibold mb-4">Agent Grid</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {agents.map(agent => (
          <div
            key={agent.name}
            className="bg-slate-800 border border-slate-700 rounded-xl p-4 flex flex-col gap-2 hover:border-slate-500 transition-colors"
          >
            <div className="flex items-center justify-between">
              <span className="text-2xl">{agent.emoji}</span>
              <PulseRing status={agent.status || 'idle'} />
            </div>
            <div>
              <div className="font-bold text-white">{agent.name}</div>
              <div className="text-xs text-slate-400">{agent.role}</div>
            </div>
            {loading ? (
              <div className="h-3 bg-slate-700 rounded w-3/4 animate-pulse" />
            ) : (
              <>
                <div className="text-xs text-slate-300 truncate" title={agent.current_task || ''}>
                  {agent.current_task || <span className="text-slate-600">No active task</span>}
                </div>
                <div className="text-xs text-slate-500">
                  Last seen: {timeAgo(agent.last_seen || agent.updated_at)}
                </div>
              </>
            )}
            <div className={`text-xs font-medium mt-1 ${
              agent.status === 'active' ? 'text-emerald-400' :
              agent.status === 'idle' ? 'text-slate-400' :
              'text-slate-500'
            }`}>
              {agent.status ? agent.status.toUpperCase() : 'OFFLINE'}
            </div>
          </div>
        ))}
      </div>
    </section>
  )
}

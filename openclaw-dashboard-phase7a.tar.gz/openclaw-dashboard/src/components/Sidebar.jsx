import { NavLink } from 'react-router-dom'

const NAV_ITEMS = [
  { to: '/',         label: 'Command Center', icon: '🖥️' },
  { to: '/agents',   label: 'Agents',         icon: '🤖' },
  { to: '/logs',     label: 'Logs',           icon: '📋' },
  { to: '/costs',    label: 'Costs',          icon: '💰' },
  { to: '/settings', label: 'Settings',       icon: '⚙️' },
]

export default function Sidebar() {
  return (
    <aside className="w-60 shrink-0 bg-slate-900 border-r border-slate-800 flex flex-col h-screen sticky top-0">
      {/* Logo / Brand */}
      <div className="px-6 py-5 border-b border-slate-800">
        <div className="flex items-center gap-2">
          <span className="text-2xl">🎩</span>
          <div>
            <div className="font-bold text-white text-sm leading-tight">OpenClaw</div>
            <div className="text-xs text-slate-500">Agent OS v3</div>
          </div>
        </div>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        {NAV_ITEMS.map(item => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.to === '/'}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                isActive
                  ? 'bg-indigo-600/20 text-indigo-300 border border-indigo-700/40'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800'
              }`
            }
          >
            <span className="text-base">{item.icon}</span>
            {item.label}
          </NavLink>
        ))}
      </nav>

      {/* Footer */}
      <div className="px-6 py-4 border-t border-slate-800">
        <p className="text-xs text-slate-600">Phase 7a · Command Center</p>
      </div>
    </aside>
  )
}
